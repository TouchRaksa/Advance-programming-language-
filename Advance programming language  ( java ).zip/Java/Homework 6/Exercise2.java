import java.util.Scanner;

public class Exercise2 {

    // Method to check if a number is both even and a palindrome
    boolean isEvenPalindrome(int num) {
        if (num % 2 != 0) return false; // Check even condition
        
        int original = num, reverse = 0;
        
        while (num != 0) {
            int digit = num % 10;
            reverse = reverse * 10 + digit;
            num /= 10;
        }
        return original == reverse; // Check palindrome condition
    }

    // Method to generate even palindromes
    void EvenPalindrome() {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the number of even palindromes: ");
        int number = input.nextInt();
        input.close();
        int[] value = new int[number]; // Array to store even palindromes
        int count = 0; // Count of found palindromes
        int num = 0; // Starting number

        while (count < number) {
            if (isEvenPalindrome(num)) {
                value[count] = num;
                count++;
            }
            num++;
        }

        // Printing the even palindromes
        System.out.print("Even Palindromes: ");
        for (int i = 0; i < number; i++) {
            System.out.print(value[i] + " ");
        }
    }
    public static void main(String[] args) {
        Exercise2 obj = new Exercise2(); // Create an object
        obj.EvenPalindrome(); // Call the method
    }
}
