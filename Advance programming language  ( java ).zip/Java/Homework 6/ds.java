public class ds {
    static void GenerateEvenPalindromeNumbers(int limit) {
        int palinCount = 0; 
        int num = 0; 
        while (palinCount < limit) {
            if (num % 2 == 0 && isPalindrome(num)) { 
                System.out.println(num); 
                palinCount++;
            }
            num++;
        }
    }

    // Function to check if a number is a palindrome
    static boolean isPalindrome(int num) {
        String str = String.valueOf(num);
        StringBuilder reverseStr = new StringBuilder(str);
        reverseStr.reverse();

        return str.equals(reverseStr.toString());//compare str and reverseStr
    }

    public static void main(String[] args) {
        GenerateEvenPalindromeNumbers(10); // Display the first 10 palindrome even numbers
    }
}