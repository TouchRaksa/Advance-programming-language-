import java.util.Scanner;

class Exercise {

    // Function to check if a number is a palindrome
    static boolean isPalindrome(int num) {
        // Convert number to string
        String str = String.valueOf(num);
        // Rverse the string
        StringBuilder reverseStr = new StringBuilder(str).reverse(); 

        return str.equals(reverseStr.toString());//compare str and reverseStr
    }

    // Generate even number of palidrome
    static int[] generateEvenNumeralPalindrome(int numLimit) {
        // create array to store palindrome num
        int[] palindrome = new int[numLimit];
        // Count number of palindrome found
        int count = 0; 
        // Check from 0
        int num = 0; 

        while (count < numLimit) {
            // Check if the number is even and palindrome number
            if (num % 2 == 0 && isPalindrome(num)) { 
                // Store palindrome in the array
                palindrome[count] = num; 
                count++;
            }

            // move to the  next number 
            num++;
        }

        return palindrome;
    }

    public static void main(String[] args) {

        // Input the how many even palindromes numbers you want 
        Scanner input = new Scanner(System.in);
        System.out.print("How many even palindromes do you want? :  ");
        int numLimit = input.nextInt();
        
        // Generate even palindrome number
        int[] palindrome = generateEvenNumeralPalindrome(numLimit);

        // Display the result
        System.out.print("Even palindromes: ");
        for (int i = 0; i < palindrome.length; i++) {
            System.out.print(palindrome[i] + " ");

        }

        input.close();
    }
}
