public class Exercise8 {
    void leader() {
        int[] array = new int[10];

        // Generate random numbers and print the array
        System.out.print("Array: ");
        for (int i = 0; i < 10; i++) {
            array[i] = (int)(Math.random() * 100);
            System.out.print(array[i] + " ");
        }
        System.out.println();

        // Find and display leaders
        System.out.print("Leaders: ");
        int maxFromRight = array[9]; // Last element is always a leader
        System.out.print(maxFromRight + " ");

        for (int i = 8; i >= 0; i--) { // Traverse from right to left
            if (array[i] > maxFromRight) {
                maxFromRight = array[i];
                System.out.print(maxFromRight + " ");
            }
        }
    }

    public static void main(String[] args) {
        Exercise8 obj = new Exercise8(); // Correctly instantiate the object
        obj.leader(); // Call the leader function
    }
}