public class Exercise7 {
    int ArrayRandom() {
        int[][] array = new int[3][4];
        int largest = Integer.MIN_VALUE; // Initialize with smallest possible integer

        // Fill array with random values and find the largest number
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 4; col++) {
                array[row][col] = (int) (Math.random() * 50); // Random values from 0 to 49
                System.out.print(array[row][col] + " "); // Print array elements
                if (array[row][col] > largest) {
                    largest = array[row][col]; // Update largest number
                }
            }
            System.out.println(); // New line for formatting
        }

        return largest; // Return the largest number
    }

    public static void main(String[] args) {
        Exercise7 obj = new Exercise7(); // Create an object
        int max = obj.ArrayRandom(); // Call method and get the largest number
        System.out.println("Largest number: " + max); // Print the largest value
    }
}