// We don`t use static coz it`s one obj
public class Instand {
    int num(int x){
        return x * x;
    }
    public static void main(String[] args) {
        Instand obj = new Instand();
        System.out.println(obj.num(5));
    }
}