public class Program {
    int data = 10;
    void change (int data){
        data = 50;
    }
    public static void main(String[] args) {
        Program obj = new Program();
        System.out.println(obj.data);
        obj.change(obj.data);
        System.out.println(obj.data);
    }
}