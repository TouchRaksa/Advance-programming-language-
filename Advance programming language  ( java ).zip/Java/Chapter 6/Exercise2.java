public class Exercise2 {
    static final int num = 10;
    public static void main(String[] args) {
        System.out.println("number is " + Exercise2.num);
    }
}
