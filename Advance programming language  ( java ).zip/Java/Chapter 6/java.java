
public class java {
    int num = 20;
    public static void main(String[] args) {
        java obj = new java();
        java obj1 = new java();
        obj.num = 10;
        System.out.println(obj.num);
        System.out.println(obj1.num);
    }
}
