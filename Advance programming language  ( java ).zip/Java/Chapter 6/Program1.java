public class Program1 {
    int num = 10;
    void change(Program1 fdh) {
        num = 20;
    }
    public static void main(String[] args) {
        Program1 obj = new Program1();
        System.out.println(obj.num);
        obj.change(obj);
        System.out.println(obj.num);
    }
}