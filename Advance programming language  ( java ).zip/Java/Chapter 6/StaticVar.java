
public class StaticVar {
    static int num = 10;
    public static void main(String[] args) {
        StaticVar obj = new StaticVar();
        StaticVar obj1 = new StaticVar();
        StaticVar.num = 20;
        System.out.println(obj.num);
        System.out.println(obj1.num);
        System.out.println(StaticVar.num);
    }
}