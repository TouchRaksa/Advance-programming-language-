// We use Static for more obj in a memories
public class Static {
    static int num(int x){
        return x * x;
    }
    public static void main(String[] args) {
        System.out.println(Static.num(5));
        System.out.println(Static.num(10));
    }
}
