class Program {
    static void value (int age) {
        if (age < 10) {
            
        }
    }
}

public class Example5 {
    
}
