import java.util.Scanner;
public class Example2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] array = {1, 2, 3};

        System.out.println("Enter index: ");
        int index = input.nextInt();
        input.close();

        try {
            System.out.println("Element is: " +array[index]);
            System.out.println("Rest of code in the try blook");
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        } finally {
            System.out.println("This is finally");
        }
    }
}