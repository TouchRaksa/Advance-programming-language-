public class Example3 {
    public static void main(String[] args) {
        try {
            int[] array = new int[10];
            array[20] = 30 / 0;
        } catch (ArithmeticException e) {
            System.out.println(e);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}