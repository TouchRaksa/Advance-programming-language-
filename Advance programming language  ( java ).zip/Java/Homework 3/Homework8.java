public class Homework8 {
    public static void main(String[] arg) {
        // Initialize and populate the array with numbers from 1 to 50
        int[] array = new int[50];
        for (int i = 0; i < array.length; i++) {
            array[i] = i + 1; // Populate the array with values 1 to 50
        }

        int count = 0; // To count the non-prime numbers

        System.out.print("Lockers open: ");
        for (int i = 0; i < array.length; i++) {
            boolean bool = true;
            int number = array[i];

            if (number == 1) {
                // 1 is not a prime number
                System.out.print(number + " ");
                count++;
            } else if (number > 1) {
                // Check if the number is divisible by any number from 2 to √number
                for (int j = 2; j <= Math.sqrt(number); j++) {
                    if (number % j == 0) {
                        bool = false; // Not a prime number
                        break;
                    }
                }

                if (!bool) {
                    System.out.print(number + " "); // Print the non-prime number
                    count++;
                }
            }
        }
        System.out.println("\nTotal lockers open: " + count);
    }
}
