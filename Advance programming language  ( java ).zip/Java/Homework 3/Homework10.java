import java.util.Scanner;

public class Homework10 { 
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Arrays for words representation
        String[] word = {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine",
                         "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", 
                         "eighteen", "nineteen"};
        String[] wordthan = {"twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"};
        String[] endWord = {"hundred"};

        // Prompt for input
        System.out.print("Input number you want to know (0 - 999): ");
        int number = input.nextInt();
        input.close();

        if (number < 0 || number > 999) {
            System.out.println("Number out of range. Please enter a number between 0 and 999.");
        }
        StringBuilder result = new StringBuilder();
        
        if (number == 0) {
            result.append(word[0]);
        } else {
            // Number >= 100
            if (number / 100 > 0) {
                result.append(word[number / 100]).append(" ").append(endWord[0]).append(" ");
                number %= 100;
            }
            // Number >= 10
            if (number >= 20) {
                result.append(wordthan[number / 10 - 2]).append(" ");
                number %= 10; 
            }
            // Number > 0
            if (number > 0) {
                result.append(word[number]);
            }
        }
        System.out.println("It is " + result);
    }
}