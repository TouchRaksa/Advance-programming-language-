import java.util.Scanner;

public class ddd { 
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Arrays for words representation
        String[] word = {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine",
                         "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", 
                         "eighteen", "nineteen"};
        String[] wordThan = {"twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"};
        String endWord = "hundred";

        // Prompt for input
        System.out.print("Input number you want to know (0 - 999): ");
        int number = input.nextInt();
        input.close();

        if (number < 0 || number > 999) {
            System.out.println("Number out of range. Please enter a number between 0 and 999.");
            return;
        }

        StringBuilder result = new StringBuilder();

        // Handle 0 explicitly
        if (number == 0) {
            result.append(word[0]);
        } else {
            // Handle hundreds place
            if (number / 100 > 0) {
                result.append(word[number / 100]).append(" ").append(endWord).append(" ");
                number %= 100; // Reduce the number to less than 100
            }

            // Handle numbers between 20 and 99
            if (number >= 20) {
                result.append(wordThan[number / 10 - 2]).append(" ");
                number %= 10; // Reduce the number to less than 10
            }

            // Handle numbers less than 20
            if (number > 0) {
                result.append(word[number]).append(" ");
            }
        }

        // Output the result
        System.out.println("The number is: " + result);
    }
}
