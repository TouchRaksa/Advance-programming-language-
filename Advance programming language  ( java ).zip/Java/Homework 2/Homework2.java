import java.util.Scanner;

public class Homework2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Input your word: "); //print
        String word = input.nextLine(); //input
        
        char[] character = word.toCharArray();
        // Find Uppercase and Lowercase
        for (int i = 0; i < character.length; i++) {
            if (Character.isUpperCase(character[i])) {
                System.out.print(" " + character[i] + " ");
            } else if (Character.isLowerCase(character[i])) {
                System.out.print(character[i]);
            }
        }
        input.close();
    }
}