public class Homework5 {
    public static void main(String[] args) {
        String amino = "GIVEQCCTSICSLYQLENYCNFVNQHLCGSHLVEALYLVCGERGFFYTPKTNQHERGFFYTPKSICSLYQLVCGEVEQCCTTSICSLYLCGSHRGFFYTLVECGEALYLHERGICSLYQLENYCNFVNQHLCGSHLVEALYLVCGERGFFYTPKTNQHERGFFYTPKSICSLYQLVCGEVEQCCTTSICSLYLCGSQCCTTSICSLYLCGSHRGFFYTLVECGEALYLHERGICSLYQLENYCNFVNQHL";
        char[] word = amino.toCharArray();
        int totalA = 0, totalC = 0, totalD = 0, totalE = 0, totalF = 0, totalG = 0, totalH = 0, totalI = 0, totalK = 0, totalL = 0, totalM = 0, totalN = 0, totalP = 0, totalQ = 0, totalR = 0, totalS = 0, totalT = 0, totalV = 0, totalW = 0, totalY = 0;
        for (int i = 0; i < amino.length(); i++){
            if (word[i] == 'A'){
                int a = 0;
                a++;
                totalA += a;
            } else if (word[i] == 'C'){
                int c = 0;
                c++;
                totalC += c;
            } else if (word[i] == 'D'){
                int d = 0;
                d++;
                totalD += d;
            } else if (word[i] == 'E'){
                int e = 0;
                e++;
                totalE += e;
            } else if (word[i] == 'F'){
                int f = 0;
                f++;
                totalF += f;
            } else if (word[i] == 'G'){
                int g = 0;
                g++;
                totalG += g;
            } else if (word[i] == 'H'){
                int h = 0;
                h++;
                totalH += h;
            } else if (word[i] == 'I'){
                int I = 0;
                I++;
                totalI += I;
            } else if (word[i] == 'K'){
                int k = 0;
                k++;
                totalK += k;
            } else if (word[i] == 'L'){
                int l = 0;
                l++;
                totalL += l;
            } else if (word[i] == 'M'){
                int m = 0;
                m++;
                totalM += m;
            } else if (word[i] == 'N'){
                int n = 0;
                n++;
                totalN += n;
            } else if (word[i] == 'P'){
                int p = 0;
                p++;
                totalP += p;
            } else if (word[i] == 'Q'){
                int q = 0;
                q++;
                totalQ += q;
            } else if (word[i] == 'R'){
                int r = 0;
                r++;
                totalR += r;
            } else if (word[i] == 'S'){
                int s = 0;
                s++;
                totalS += s;
            } else if (word[i] == 'T'){
                int t = 0;
                t++;
                totalT += t;
            } else if (word[i] == 'V'){
                int v = 0;
                v++;
                totalV += v;
            } else if (word[i] == 'W'){
                int w = 0;
                w++;
                totalW += w;
            } else if (word[i] == 'Y'){
                int y = 0; 
                y++;
                totalY += y;
            }
        }
        System.out.println("A: " + totalA + " C: " + totalC + " D: " + totalD + " E: " + totalE +
                " F: " + totalF + " G: "+totalG+" H: "+totalH+" I: "+totalI+" K: "+totalK+" L: "+totalL+
                " M: "+totalM+" N: "+totalN+" P: "+totalP+" Q: "+totalQ+" R: "+totalT+" S: "+totalR+" T: "+totalS+" V: "+totalV+
                " W: "+totalW+" Y: "+totalY);
    }
}