public class zzz {        
    public static void main(String[] args) {

        String proteinSequence = "GIVEQCCTSICSLYQLENYCNFVNQHLCGSHLVEALYLVCGERGFFYTPKTNQHERGFFYTPKSICSLYQLVCGEVEQCCTTSICSLYLCGSHRGFFYTLVECGEALYLHERGICSLYQLENYCNFVNQHLCGSHLVEALYLVGERGFFYTPKTNQHERGFFYTPKSICSLYQLVCGEVEQCCTTSICSLYLCGSQCCTTSICSLYLCGSHRGFFYTLVECGEALYLHERGICSLYQLENYCNFVNQHL";
        String aminoAcids = "ACDEFGHIKLMNPQRSTVWY";

        // Loop through amino acids to count each amino acid
        for(int i = 0; i < aminoAcids.length(); i++){
            int count = 0;

            // Loop through each amino acid in the protein sequence
            for(int j = 0; j < proteinSequence.length(); j++){
                // Count the amino acid
                if(aminoAcids.charAt(i) == proteinSequence.charAt(j)){
                    count++;
                }
            }

            // Display the result
            System.out.println(aminoAcids.charAt(i) + " : " + count);
        }
    }
}
