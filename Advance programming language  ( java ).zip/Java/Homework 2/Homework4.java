import java.util.Scanner;

public class Homework4 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Input your word: ");
        String word = input.nextLine();

        // Make the word lowercase for case-insensitive comparison
        String normalizedWord = word.toLowerCase();

        // Reverse the word
        StringBuilder reverse = new StringBuilder(normalizedWord);
        reverse.reverse();

        // Check if the word is a palindrome
        if (normalizedWord.equals(reverse.toString())) {
            System.out.println("\"" + word + "\" is a palindrome.");
        } else {
            System.out.println("\"" + word + "\" is not a palindrome.");
        }

        input.close();
    }
}