
import java.util.Scanner;

public class Homework {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Input Your Word: ");
        String word = input.nextLine();//Input word by user
        
        String reverse="";//create a variable to store the word as a string

        //Make the word reverse
        for (int i = word.length() - 1; i >= 0; i--) {
            reverse += word.charAt(i);
        }

        //Check the condition between word and reverse word
        if (word.equalsIgnoreCase(reverse)) {
            System.out.print("The Word: " + word + " is a palindrome word");
        }
        else {
            System.out.print("The Word: "+word+" is not a palindrome word");
        }
        input.close();
    }
}

