import java.util.Scanner;

public class Homework1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Input a sentence: ");
        StringBuilder word =new StringBuilder(input.nextLine());

        input.close();

        // Convert StringBuilder to char array
        char[] letter = word.toString().toCharArray();
        for (int i = 0; i < word.length(); i++) {
            int number = (int) letter[i]; // Get ASCII value of the character
            if (letter[i] == ' ') { 
                System.out.print(' ');
                continue; // Skip to the next iteration
            } else if (letter[i] == 'z') {
                System.out.print("a");
                continue;
            } else if (letter[i] == 'Z') {
                System.out.print("A");
                continue;
            }
            number++; // Increment ASCII value
            char letters = (char) number; // Convert back to character
            System.out.print(letters); // Print the incremented character
        }
    }
}