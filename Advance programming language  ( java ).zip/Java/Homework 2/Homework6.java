import java.util.Scanner;

public class Homework6 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        char[] word = input.nextLine().toCharArray();
        input.close();

        StringBuilder result = new StringBuilder();
        boolean[] seen = new boolean[256]; // To track seen characters (ASCII)

        for (int i = 0; i < word.length; i++) {
            char letter = word[i];
            if (Character.isLetter(letter)) {
                // Only append the letter if it hasn't been added before
                if (!seen[letter]) {
                    result.append(letter);
                    seen[letter] = true; // Mark the letter as seen
                }
            } else {
                // Append non-letter characters (like spaces and punctuation) as is
                result.append(letter);
            }
        }
        System.out.println(result.toString());
    }
}
