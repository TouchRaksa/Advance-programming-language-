import java.util.Scanner;

public class Homework7 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Input your sentence you want to input: ");

        String word = input.nextLine(); // Read the input string
        char[] letter = word.toCharArray(); // Convert the string to a character array

        for (int i = 0; i < word.length(); i++) {
            if (i == 0 && Character.isLowerCase(letter[i]) || letter[i - 1] == ' '){
                System.out.print(Character.toUpperCase(letter[i]));
            } else if (Character.isUpperCase(letter[i])) {
                System.out.print(Character.toLowerCase(letter[i])); // Convert and print uppercase as lowercase
            } else {
                System.out.print(letter[i]);
            }
        }
        input.close(); // Close the scanner
    }
}