import java.util.Scanner;

public class Homework3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        char[] vovel = {'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U'};
        System.out.print("Enter a sentence: ");
        char[] word = input.nextLine().toCharArray();
        input.close();

        StringBuilder sentence = new StringBuilder();
        for (int i = 0; i < word.length; i++) {
            for (int j = 0; j < vovel.length; j++) {
                if (word[i] == vovel[j]) {
                    sentence.append(word[i]);
                } else {
                    continue;
                }
            }
            if (word[i] == ' ') {
                sentence.append(' ');
            }
        }       
        System.out.print(sentence);
    }
}
