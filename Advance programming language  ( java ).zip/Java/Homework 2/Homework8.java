import java.util.Scanner;
public class Homework8 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        boolean found = true;
        System.out.print("input your password: ");
        String password = input.next(); // input 
        input.close();
        char[] number = password.toCharArray(); // Change String to char
        int size = 8;
        if (password.length() != size) { // input != 8
            System.out.println("Password must have 8 character");
        } else {
            int countletter = 0;
            int countdigit = 0; 
            int inval = 0;
            for (int i = 0; i < number.length; i++) {
                if(Character.isLetter(password.charAt(i))) {
                    countletter ++;
                } else if (Character.isUpperCase(i)) {
                    found = true;
                } else if (Character.isDigit(password.charAt(i))) {
                    countdigit ++;
                } else if (Character.isLowerCase(password.charAt(i))){
                    found = true;
                } else {
                    inval ++;
                }
            }
            if (inval > 0){
                System.out.println("Password must digit and letter but no space");
            } else if (countletter == 0 || countdigit == 0) {
                System.out.println("Password must have digit and letter");
            } else if (!Character.isDigit(password.charAt(0))) {
                System.out.println("Password must start by digit");
            } else if (!found) {
                System.out.println("Password must have upper letter");
            } else if (found) {
                System.out.println("Password must have not lower letter");
            } else {
                System.out.println("It`s sucess");
            }
        }
    }
}