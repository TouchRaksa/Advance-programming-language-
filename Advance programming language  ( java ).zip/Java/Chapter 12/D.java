class Vehicle {
    String name;
    void show () {
        System.out.println("Vehicle name is " + name);
    }
}
class car extends Vehicle {
    car (String name) {
        this.name = name;
    }
    void showcar () {
        System.out.println("car name is " + name);
    }
}
class truck extends Vehicle {
    truck (String name) {
        this.name = name;
    }
    void showtruck () {
        System.out.println("truck name is " + name);
    }
}
public class D {
    public static void main(String[] args) {
        car car1 = new car("bmw");
        truck truck1 = new truck("ford");

        car1.show();
        car1.showcar();

        truck1.show();
        truck1.showtruck();
    }
}
