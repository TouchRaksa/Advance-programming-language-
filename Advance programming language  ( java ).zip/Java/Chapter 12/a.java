class animal {
    String name;
    void eat() {
        System.out.println("The animal is eating");
    }
}
class dog extends animal {
    void display() {
        System.out.println("It`s name is the " + name);
    }
}
public class a {
    public static void main(String[] args) {
        dog dog1 = new dog();
        dog1.name = "Lucky";
        dog1.eat();
        dog1.display();
    }
}