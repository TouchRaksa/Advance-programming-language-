class vehicle {
    void showvehicle() {
        System.out.println("this is a vehicle");
    }
}

class car extends vehicle {
    void showcar() {
        System.out.println("this is a car");
    }
}

class sportcar extends car{
    void showsportcar() {
        System.out.println("this is a sport car");
    }
}
public class E {
    public static void main(String[] args) {
        sportcar sport_car = new sportcar();

        sport_car.showvehicle();
        sport_car.showcar();
        sport_car.showsportcar();
    }
}
