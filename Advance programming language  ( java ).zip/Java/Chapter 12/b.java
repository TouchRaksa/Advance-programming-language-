class parent {
    parent() {
        System.out.println("parent constructor is called");
    }
}
class child extends parent {
    child () {
        System.out.println("child constructor is called");
    }
}
public class b {
    public static void main(String[] args) {
        child child1 = new child();
    
    }
}