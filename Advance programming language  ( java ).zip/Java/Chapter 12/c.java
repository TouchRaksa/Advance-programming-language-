class parent {
    String name;
    parent() {
        System.out.println("parent constructor is called");
    }
    parent(String name) {
        this.name = name;
        System.out.println("the parent name is " + name);
    }
}
class child extends parent {
    child(String name) {
        System.out.println("child name is " + name);
    }
}
public class c {
    public static void main(String[] args) {
        child child1 = new child("lala");
    }
}  '