class vehicle {
    String name;
    void showvehicle() {
        System.out.println("vehicle name is " + name);
    }
}

class car extends vehicle {
    car (String name) {
        this.name = name;
    }
    void showcar() {
        System.out.println("car name is " + name);
    }
} 

class truck extends vehicle {
    truck (String name) {
        this.name = name;
    }
    void showtruck() {
        System.out.println("truck name is " + name);
    }
}

public class F {
    public static void main(String[] args) {
        car cars = new car("bmw");
        truck trucks = new truck("ford");

        cars.showvehicle();
        cars.showcar();
        trucks.showvehicle();
        trucks.showtruck();
    }
}
