public class Exercise10 {
    public static void main(String[] args) {
        // Possible ways to distribute pearls
        String[][] choices = {
                { "WWW", "BBB" }, // Choice 1: All whites in one bowl, all blacks in another
                { "WW", "WBBB" } // Choice 2: Two whites in one bowl, one white and all blacks in another
        };

        for (int choiceIndex = 0; choiceIndex < choices.length; choiceIndex++) {
            String[] bowls = choices[choiceIndex];
            int survivalCount = 0;

            for (int round = 0; round < 100; round++) {
                // Randomly pick one of the two bowls
                int selectedBowlIndex = (Math.random() < 0.5) ? 0 : 1; // 50% chance for each bowl
                String selectedBowl = bowls[selectedBowlIndex];

                // Randomly pick one pearl from the selected bowl
                int pickedPearlIndex = (int) (Math.random() * selectedBowl.length());
                char pickedPearl = selectedBowl.charAt(pickedPearlIndex);

                if (pickedPearl == 'W') {
                    survivalCount++;
                }
            }

            // Display the results
            System.out.println("Choice " + (choiceIndex + 1) + ": " +
                    "[" + bowls[0] + "] and [" + bowls[1] + "], " +
                    "the number of survivals is " + survivalCount + " / 100 times");
        }
    }
}