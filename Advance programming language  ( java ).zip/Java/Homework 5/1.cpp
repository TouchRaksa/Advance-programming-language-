#include <iostream>
using namespace std;

void u(int x) {
}