import java.util.Random;
public class Homework9 {
    public static void main(String[] args) {
        Random rand = new Random();
        int[] shotCount = new int[6]; // Tracks shots for players 1-6

        for (int round = 0; round < 100; round++) {
            // Each round, all 6 players take their turn
            for (int player = 0; player < 6; player++) {
                // Roll barrel before each shot: 5 bullets, 1 empty
                int[] barrel = {1, 1, 1, 1, 1, 0}; // 5 bullets (1), 1 empty (0)
                
                // Shuffle the barrel for this player's turn
                for (int i = barrel.length - 1; i > 0; i--) {
                    int j = rand.nextInt(i + 1);
                    int temp = barrel[i];
                    barrel[i] = barrel[j];
                    barrel[j] = temp;
                }

                // Staff fires at first chamber (position 0)
                if (barrel[0] == 1) { // Bullet found
                    shotCount[player]++;
                }
            }
        }

        // Print results
        for (int i = 0; i < 6; i++) {
            System.out.println("Player " + (i + 1) + " gets shot " + shotCount[i] + " / 100 times");
        }
    }
}