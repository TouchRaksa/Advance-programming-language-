public class Homework1 {
    public static void main (String[] args) {
        int[] number = new int[10];
        int[] count = new int[10]; // Array to store counts for each number

        // Generate random numbers and count occurrences
        for (int i = 0; i < 30; i++) {
            int random = 1 + (int)(Math.random() * 10); // Generate number between 1-10
            System.out.printf("%-3d", random);

            // Increase count for the generated number
            count[random - 1]++; // -1 to match array index (1->0, 2->1, ..., 10->9)
        }

        System.out.println();
        // Loop for print number of count
        for (int i = 0; i < number.length; i++) {
            if (count[i] == 0) {}
            else if (count[i] > 1) {
                System.out.println("Number " + number[i] + " is " + count[i] + " times");
            } else {
                System.out.println("Number " + number[i] + " is " + count[i] + " time");
            }
        }
    }
}