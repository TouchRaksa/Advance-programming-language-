#include <stdio.h>
int main(){
    printf ("bye world");
    return 0;
}