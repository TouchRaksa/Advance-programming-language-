import java.util.Scanner;
public class Homework5 {
    public static void main (String[] args) {
        Scanner input = new Scanner(System.in);
        String[] name = {"Scissor", "Rock", "Paper"};

        System.out.println("Enter: 0 = Scissor, 1 = Rock, 2 = Paper");

        int number = input.nextInt();
        System.out.println("You`re " + name[number]);
        input.close();

        int random = (int)(Math.random() * 3); // Random from 0 to 2
        System.out.println(random);
        System.out.println("Computer is " + name[random]);

        // Check when it`s equal
        if (number == random) {
            System.out.println("It`s a draw");
        } 
        // Check when it`s small than
        else if (number == 0 && random == 1 || number == 1 && random == 2 || number == 2 && random == 0) {
            System.out.println("You`re lose");
        } 
        // Check when it`s big than
        else if (number == 0 && random == 2 || number == 1 && random == 0 ||number == 2 && random == 1) {
            System.out.println("You`re win");
        }
    }
}