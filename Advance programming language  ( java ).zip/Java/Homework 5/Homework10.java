public class Homework10 {
    public static void main(String[] args) {
        String[][] bools = {
            {"WWW", "BBB"}, 
            {"WW", "WBBB"}
        };
        for (int i = 0; i < bools.length; i++) {
            int rand = (int)(Math.random());
        }
    }
}