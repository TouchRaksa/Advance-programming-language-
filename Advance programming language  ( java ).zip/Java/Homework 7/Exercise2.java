import java.util.ArrayList;
import java.util.Arrays;
public class Exercise2 {
    public static void main(String[] args) {
        ArrayList<ArrayList <Integer>> number = new ArrayList<>(
            Arrays.asList(
                new ArrayList<>(Arrays.asList(1, 3)),
                new ArrayList<>(Arrays.asList(5, 7)),
                new ArrayList<>(Arrays.asList(9, 11))
            )
        );

        ArrayList<ArrayList<Integer>> number1 = new ArrayList<>(
            Arrays.asList(
                new ArrayList<>(Arrays.asList(2, 4)),
                new ArrayList<>(Arrays.asList(6, 8)),
                new ArrayList<>(Arrays.asList(10, 12, 14))
            )
        );
        System.out.print("Original: " + number + ", ");
        System.out.println(number1);

        ArrayList<ArrayList<Integer>> number2 = new ArrayList<>();
        for (int i = 0; i < number.size(); i++) {
            ArrayList<Integer> combined = new ArrayList<>(number.get(i));
            combined.addAll(number1.get(i));
            number2.add(combined); // Add combined list to number3
        }
        System.out.println("Zhip: " + number2);
    }
}
