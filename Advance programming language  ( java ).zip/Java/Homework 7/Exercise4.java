import java.util.ArrayList;
import java.util.Arrays;

public class Exercise4 {
    static void RemoveOccurence(ArrayList<Integer> arrayList) {
        ArrayList<Integer> List = new ArrayList<>();//Create new list

        //loop through arrayList to find occurence value
        for (int i = 0; i < arrayList.size(); i++) {
            int count = 0;//count time when found the same value

            for (int j = 0; j < arrayList.size(); j++) {
                if (arrayList.get(i).equals(arrayList.get(j))) {//if occurence value is found
                    count++;//Increase Time
                }
            }

            if (count == 1) {
                List.add(arrayList.get(i));//add value which are not occurence
            }
        }
        System.out.print(List);
    }

    public static void main(String[] args) {
        ArrayList<Integer> array = new ArrayList<>(//create array list
                Arrays.asList(1, 2, 3, 3, 4, 5));
        RemoveOccurence(array);
    }
}