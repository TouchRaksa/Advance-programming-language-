public class Exercise7 {
    
}