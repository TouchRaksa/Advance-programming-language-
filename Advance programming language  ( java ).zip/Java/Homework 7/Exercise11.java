import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Exercise11 {
    public static int Count(String card) {
        if (card.endsWith("Ace")) {
            return 1;
        } else if (card.endsWith("2")) {
            return 2;
        } else if (card.endsWith("3")) {
            return 3;
        } else if (card.endsWith("4")) {
            return 4;
        } else if (card.endsWith("5")) {
            return 5;
        } else if (card.endsWith("6")) {
            return 6;
        } else if (card.endsWith("7")) {
            return 7;
        } else if (card.endsWith("8")) {
            return 8;
        } else if (card.endsWith("9")) {
            return 9;
        } else if (card.endsWith("10") || card.endsWith("Jack") || card.endsWith("Queen") || card.endsWith("King")) {
            return 0;
        } else if (card.endsWith("11")) {
            return 1;
        } else if (card.endsWith("12")) {
            return 2;
        } else if (card.endsWith("13")) {
            return 3;
        } else if (card.endsWith("14")) {
            return 4;
        } else if (card.endsWith("15")) {
            return 5;
        } else if (card.endsWith("16")) {
            return 6;
        } else if (card.endsWith("17")) {
            return 7;
        } else if (card.endsWith("18")) {
            return 8;
        } else if (card.endsWith("19")) {
            return 9;
        }
        return 0;
    }
    public static void Card() {
        Scanner input = new Scanner(System.in);
        
        ArrayList<String> list = new ArrayList<>(Arrays.asList(
            "Spades Ace", "Spades 2", "Spades 3", "Spades 4", "Spades 5", "Spades 6", "Spades 7", "Spades 8", "Spades 9", "Spades 10", "Spades Jack", "Spades Queen", "Spades King",
            "Hearts Ace", "Hearts 2", "Hearts 3", "Hearts 4", "Hearts 5", "Hearts 6", "Hearts 7", "Hearts 8", "Hearts 9", "Hearts 10", "Hearts Jack", "Hearts Queen", "Hearts King",
            "Clubs Ace", "Clubs 2", "Clubs 3", "Clubs 4", "Clubs 5", "Clubs 6", "Clubs 7", "Clubs 8", "Clubs 9", "Clubs 10", "Clubs Jack", "Clubs Queen", "Clubs King",
            "Diamonds Ace", "Diamonds 2", "Diamonds 3", "Diamonds 4", "Diamonds 5", "Diamonds 6", "Diamonds 7", "Diamonds 8", "Diamonds 9", "Diamonds 10", "Diamonds Jack", "Diamonds Queen", "Diamonds King"
        ));
        int random;
        int computer = 0;
        int player = 0;
        int check = 0;

        while (check < 2) {
            // card for computer
            System.out.print("Computer is: ");
            random = (int) (Math.random() * list.size());
            String cards = list.remove(random); // use for remove card random
            System.out.println(cards);

            // use it for count of points
            computer += Count(cards);
            if (computer >= 10) {
                computer = computer / 10;
            }
    
            // card for you
            System.out.print("You are: ");
            random = (int) (Math.random() * list.size());
            String card = list.remove(random); // use for remove card random 
            System.out.println(card);

            // use it for count of points
            player += Count(card);
            if (player >= 10) {
                player = player / 10;
            }
            check ++;
        }
        // take card again
        if (computer <= 4) {
            random = (int) (Math.random() * list.size());
            String cards = list.remove(random);
            System.out.print("Third card is: " + cards);
            computer += Count(cards);
            if (computer >= 10) {
                computer = computer / 10;
            }
        }
        System.out.println();
        System.out.println("Computer points are: " + computer);
        if (computer == 8 || computer == 9) { // check to find boom
            System.out.println("computer`s boom");
        } 

        System.out.println("Your points are: " + player);
        if (player == 8 || player == 9) { // check to find boom
            System.out.println("you`s boom");
        }
        if (computer == 8 || computer == 9 || player == 8 || player == 9) {
            // Check it to find win or lose
            if (player == computer) {
                System.out.print("It`s draw");
            } else if (player < computer) {
                System.out.print("You`re lose");
            } else {
                System.out.print("You`re win");
            }
            System.exit(0);
        }
        // take a new card
        System.out.print("Do you want to take a card again? (yes/no): ");
        String answer = input.nextLine().trim();
        input.close();
        if (answer.equalsIgnoreCase("yes")) {
            random = (int) (Math.random() * list.size());
            String card = list.remove(random);
            System.out.print(card);
            player += Count(card);
            if (player >= 10) {
                player = player / 10;
            }
        }
        System.out.println();
        System.out.println("Your points are: " + player);

        // Check it to find win or lose
        if (player == computer) {
            System.out.print("It`s draw");
        } else if (player < computer) {
            System.out.print("You`re lose");
        } else {
            System.out.print("You`re win");
        }
    }

    public static void main(String[] args) {
        Card();
    }
}