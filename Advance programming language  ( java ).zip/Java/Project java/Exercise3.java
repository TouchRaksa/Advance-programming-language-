import java.util.ArrayList;

class Subject {
    String name;
    int score;

    // Constructor
    Subject(String name, int score) {
        this.name = name;
        this.score = score;
    }

    // Method to display subject details
    void displaySubjectDetail() {
        System.out.println("- " + name + ": " + score);
    }
}

class Student {
    int id;
    String name;
    ArrayList<Subject> subjects; // List of subjects

    // Constructor
    Student(int id, String name, ArrayList<Subject> subjects) {
        this.id = id;
        this.name = name;
        this.subjects = subjects;
    }

    // Method to display all subjects
    void displaySubjects() {
        System.out.println(id+","+name);
        for (Subject subject : subjects) {
            subject.displaySubjectDetail();
        }
    }
}

public class Exercise3 {
    public static void main(String[] args) {
        // Create subjects
        Subject s1 = new Subject("Java", 85);
        Subject s2 = new Subject("OOAD", 70);
        Subject s3 = new Subject("Java", 90);
        Subject s4 = new Subject("Web", 75);
        Subject s5 = new Subject("OOAD", 82);

        // Create list of subjects
        ArrayList<Subject> student1 = new ArrayList<>();
        student1.add(s1);
        student1.add(s2);
        ArrayList<Subject> student2 = new ArrayList<>();
        student2.add(s3);
        student2.add(s5);
        student2.add(s4);
        // Create a student with subjects
        Student Student1 = new Student(1, "Jonh Smith", student1);
        Student Student2 = new Student(2, "Lucy Brown", student2);

        // Display student and their subjects
        Student1.displaySubjects();
        Student2.displaySubjects();
    }
}
