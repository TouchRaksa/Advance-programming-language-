import java.util.Scanner;
public class SystemLogin {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print ("Full naame: ");
        String word = input.nextLine();
        System.out.print ("Password: ");
        int number = input.nextInt();
        input.close();

        System.out.println (word);
        System.out.println (number);
    }
}