import java.util.ArrayList;
import java.util.Scanner;

public class Exercise1ch10 {

    public static void main(String[] args) {
        // Initialize an ArrayList with initial values
        ArrayList<String> array = new ArrayList<>();
        array.add("One");
        array.add("Two");
        array.add("Three");

        int choice; // stores user menu choice
        int index;  // stores index to access array elements
        Scanner input = new Scanner(System.in); // Scanner for user input

        // Start an infinite loop for the menu
        while (true) {
            // Display all items in the array
            System.out.println("All items in array:");
            System.out.println(array);

            // Show the menu options
            System.out.println("Input choice:");
            System.out.println("1 - Add text");
            System.out.println("2 - Display by index");
            System.out.println("3 - Exit");

            try {
                // Read and parse user choice as integer
                choice = Integer.parseInt(input.nextLine());
            } catch (NumberFormatException e) {
                // Handle non-integer input
                System.out.println("Choice should be an integer! Try again.");
                // Don't need input.nextLine() here since input.nextLine() already consumed the invalid input
                continue; // Restart loop
            }

            // Handle each menu option
            switch (choice) {
                case 1:
                    // Add a new string to the array
                    System.out.println("What do you want to add?");
                    String str = input.nextLine(); // Read user input as a full line
                    array.add(str); // Add to list
                    System.out.println("Added!");
                    break;

                case 2:
                    // Display a value at a specific index
                    System.out.println("Input index to display: ");
                    try {
                        // Parse index input
                        index = Integer.parseInt(input.nextLine());
                        // Print value at given index
                        System.out.println("Value: " + array.get(index));
                    } catch (NumberFormatException e) {
                        // Handle non-integer index input
                        System.out.println("Index must be a number!");
                        continue;
                    } catch (IndexOutOfBoundsException e) {
                        // Handle index out of valid range
                        System.out.println("Index out of bounds!");
                        continue;
                    }
                    break;

                case 3:
                    // Exit the program
                    input.close(); // Close scanner to prevent resource leak
                    System.out.println("Exiting...");
                    return;

                default:
                    // Handle invalid menu choices
                    System.out.println("Invalid choice!");
                    break;
            }
        }
    }
}