import java.util.ArrayList;

public class Bz {
    public static void main(String[] args){
        ArrayList <String> list = new ArrayList<>();
        list.add("Haha");
        list.add("Lala");
        System.out.println(list);
    }
}