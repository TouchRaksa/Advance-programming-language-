import java.util.ArrayList;

public class G {
    public static void main(String[] args) {
        ArrayList <String> animal = new ArrayList<>();
        animal.add("Cat");
        animal.add("Dog");
        animal.add("Fox");

        String str = animal.set(1, "Tiger");
        for (String i : animal) {
            System.out.print(i + "\t");
        }
        System.out.println(str);
    }
}