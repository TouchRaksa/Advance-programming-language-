import java.util.ArrayList;

public class E {
    public static void main(String[] args) {
        ArrayList <String> animal = new ArrayList<>();
        animal.add("Cat");
        animal.add("Dog");
        animal.add("Fox");

        String str = animal.get(1);
        System.out.println(animal);
        System.out.println(str);
    }
}