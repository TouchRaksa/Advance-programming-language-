import java.util.ArrayList;

public class C{
    public static void main(String[] args){
        ArrayList<String> list = new ArrayList<>();
        list.add("Java");
        list.add("PHP");
        list.add("Javascript");

        list.add(2, "Ruby");

        System.out.println(list);
    }
}