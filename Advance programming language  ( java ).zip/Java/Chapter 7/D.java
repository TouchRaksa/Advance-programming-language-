import java.util.ArrayList;

public class D {
    public static void main(String[] args) {
        ArrayList <String> language1 = new ArrayList<>();

        ArrayList <String> language2 = new ArrayList<>();
        language2.add("PHP");
        language2.add("C#");

        ArrayList <String> language3 = new ArrayList<>();
        language3.add("Java");
        language3.add("Python");

        ArrayList <String> language4 = new ArrayList<>();
        language4.add("C++");
        language4.add("Ruby");

        language1.addAll(language4);
        language2.addAll(0,language4);
        language3.addAll(language4);

        System.out.println(language1);
        System.out.println(language2);
        System.out.println(language3);
    }
}