import java.util.ArrayList;
import java.util.Arrays;

public class F {
    public static void main(String[] args) {
        ArrayList <String> language = new ArrayList<> (
            Arrays.asList("Cat", "Dog", "Bee")
        );
        language.add(1, "Ant");

        ArrayList <String> animal1 = new ArrayList<> (
            Arrays.asList("Cat", "Dog", "Bee")
        );
        animal1.set(1, "Sheep");

        System.out.println(language);
        System.out.println(animal1);
    }
}