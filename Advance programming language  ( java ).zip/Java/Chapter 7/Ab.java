import java.util.ArrayList;
import java.util.Arrays;

public class Ab {
    public static void main(String[] args){
        ArrayList<String> arraylist = new ArrayList<>();

        arraylist.add("Yaya");
        arraylist.add("Sasa");
        arraylist.add("Lala");

        ArrayList<String> arraylist1 = new ArrayList<>(
            Arrays.asList("java", "Php", "Ruby")
        );

        ArrayList<String> arraylist2 = new ArrayList<>(arraylist);
        System.out.println(arraylist);
        System.out.println(arraylist1);
        System.out.println(arraylist2);
    }
}