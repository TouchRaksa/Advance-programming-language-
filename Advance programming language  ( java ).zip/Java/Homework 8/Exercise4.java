import java.util.HashMap;
public class Exercise4 {
    public static void main(String[] args) {
        HashMap <Integer, Integer> employee1 = new HashMap<>();
        employee1.put(1, 0);
        employee1.put(2, 5);
        employee1.put(3, 8);
        employee1.put(4, 3);
        employee1.put(5, 2);
        employee1.put(6, 7);
        employee1.put(7, 3);
        int times1 = 0;
        for (int hour : employee1.values()) {
            times1 += hour;
        }
        int salary1 = 0;
        if (times1 <= 30) {
            salary1 = times1 * 5;
        } else {
            salary1 = times1 * 10;
        }

        HashMap <Integer, Integer> employee2 = new HashMap<>();
        employee2.put(1, 5);
        employee2.put(2, 2);
        employee2.put(3, 3);
        employee2.put(4, 2);
        employee2.put(5, 4);
        employee2.put(6, 2);
        employee2.put(7, 2);
        int times2 = 0;
        for (int hour : employee2.values()) {
            times2 += hour;
        }
        int salary2 = 0;
        if (times2 <= 30) {
            salary2 = times2 * 5;
        } else {
            salary2 = times2 * 10;
        }

        HashMap <Integer, Integer> employee3 = new HashMap<>();
        employee3.put(1, 7);
        employee3.put(2, 6);
        employee3.put(3, 2);
        employee3.put(4, 3);
        employee3.put(5, 8);
        employee3.put(6, 7);
        employee3.put(7, 6);
        int times3 = 0;
        for(int hour : employee3.values()) {
            times3 += hour;
        }
        int salary3 = 0;
        if (times3 <= 30) {
            salary3 = times3 * 5;
        } else {
            salary3 = times3 * 10;
        }

        HashMap <Integer, Integer> employee4 = new HashMap<>();
        employee4.put(1, 4);
        employee4.put(2, 7);
        employee4.put(3, 8);
        employee4.put(4, 5);
        employee4.put(5, 7);
        employee4.put(6, 2);
        employee4.put(7, 6);
        int times4 = 0;
        for (int hour : employee4.values()) {
            times4 += hour;
        }
        int salary4 = 0;
        if (times4 <= 30) {
            salary4 = times4 * 5;
        } else {
            salary4 = times4 * 10;
        }

        HashMap<Integer, Integer> employee5 = new HashMap<>();
        employee5.put(1, 2);
        employee5.put(2, 4);
        employee5.put(3, 3);
        employee5.put(4, 6);
        employee5.put(5, 4);
        employee5.put(6, 6);
        employee5.put(7, 7);
        int times5 = 0;
        for(int hour : employee5.values()) {
            times5 += hour;
        }
        int salary5 = 0;
        if (times5 <= 30) {
            salary5 = times5 * 5;
        } else {
            salary5 = times5 * 10;
        }

        HashMap<Integer, Integer> employee6 = new HashMap<>();
        employee6.put(1, 3);
        employee6.put(2, 3);
        employee6.put(3, 7);
        employee6.put(4, 8);
        employee6.put(5, 2);
        employee6.put(6, 6);
        employee6.put(7, 8);
        int times6 = 0;
        for (int hour : employee6.values()) {
            times6 += hour;
        }
        int salary6 = 0;
        if (times6 <= 30) {
            salary6 = times6 * 5;
        } else {
            salary6 = times6 * 10;
        }

        HashMap<Integer, Integer> employee7 = new HashMap<>();
        employee7.put(1, 6);
        employee7.put(2, 5);
        employee7.put(3, 8);
        employee7.put(4, 6);
        employee7.put(5, 7);
        employee7.put(6, 5);
        employee7.put(7, 4);
        int times7 = 0;
        for (int hour : employee7.values()) {
            times7 += hour;
        }
        int salary7 = 0;
        if (times7 <= 30) {
            salary7 = times7 * 5;
        } else {
            salary7 = times7 * 10;
        }
        System.out.println(".................................");
        System.out.printf("%-12s %-10s %-10s\n", "Name", "Times", "Salary");
        System.out.println(".................................");
        System.out.printf("%-12s %-10d %-10d\n", "Employee1", times1, salary1);
        System.out.printf("%-12s %-10d %-10d\n", "Employee2", times2, salary2);
        System.out.printf("%-12s %-10d %-10d\n", "Employee3", times3, salary3);
        System.out.printf("%-12s %-10d %-10d\n", "Employee4", times4, salary4);
        System.out.printf("%-12s %-10d %-10d\n", "Employee5", times5, salary5);
        System.out.printf("%-12s %-10d %-10d\n", "Employee6", times6, salary6);
        System.out.printf("%-12s %-10d %-10d\n", "Employee7", times7, salary7);
        System.out.print(".................................");
    }
}