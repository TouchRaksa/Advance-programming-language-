import java.util.HashMap;
import java.util.Scanner;

public class Exercise2 {

    public static HashMap<Character, Integer> countChar(String input) {
        HashMap<Character, Integer> CountChar = new HashMap<>();

        // Convert the string to lowercase to ensure case-insensitive counting
        input = input.toLowerCase();

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (Character.isLetterOrDigit(c)) { // only count letters and digits
                if (CountChar.containsKey(c)) {
                    CountChar.put(c, CountChar.get(c) + 1);
                } else {
                    CountChar.put(c, 1);
                }
            }
        }
        return CountChar;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Please input a Sentence: ");
        String sentence = input.nextLine();
        input.close();

        HashMap<Character, Integer> result = countChar(sentence);

        Object[] keys = result.keySet().toArray(); // convert keys to an array
        for (int i = 0; i < keys.length; i++) {
            char key = (char) keys[i];
            System.out.println(key + ": " + result.get(key));
        }
    }
}