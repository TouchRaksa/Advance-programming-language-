import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class Exercise1 {
    public static void main(String[] args) {
        File file = new File ("Countries.txt");
        int count = 0;
        try {
            if (file.createNewFile()) {
                System.out.println("file create " + file.getName());
            }
            BufferedReader Reader = new BufferedReader(new FileReader(file));
            String line;

            while ((line = Reader.readLine())!= null) {
                if (line.trim().toLowerCase().endsWith("a")) {
                    count++;
                }
            }
            Reader.close();
            System.out.println("it " + count);
        } 
        catch (Exception e) {
            System.out.println(e);
        }
    }
}