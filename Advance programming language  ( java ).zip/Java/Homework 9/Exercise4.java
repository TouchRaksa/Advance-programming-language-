import java.util.Scanner;

class Account {
    String name;
    int password;
    double balance;

    Account(String name, int password, double balance) {
        this.name = name;
        this.password = password;
        this.balance = balance;
    }

    void displayInfo() {
        System.out.println("Account holder: " + name);
        System.out.printf("Balance: $%.2f\n", balance);
    }

    void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited: $" + amount);
    }

    void withdraw(double amount) {
        if (amount > balance) {
            System.out.println("Insufficient balance.");
        } else {
            balance -= amount;
            System.out.println("Withdrew: $" + amount);
        }
    }

    boolean authenticate(String inputName, int inputPassword) {
        return name.equals(inputName) && password == inputPassword;
    }
}

public class Exercise4 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Create multiple accounts
        Account[] accounts = {
            new Account("raksa", 1234, 200.0),
            new Account("hour", 5678, 300.0),
            new Account("sok", 4321, 500.0)
        };

        Account loggedInAccount = null;

        // Search for account using while loop
        while (loggedInAccount == null) {
            System.out.print("Enter name: ");
            String inputName = input.next();

            System.out.print("Enter password: ");
            int inputPassword = input.nextInt();

            for (Account acc : accounts) {
                if (acc.authenticate(inputName, inputPassword)) {
                    loggedInAccount = acc;
                    break;
                }
            }

            if (loggedInAccount == null) {
                System.out.println("Invalid credentials. Try again.");
            }
        }

        System.out.println("Login successful.");
        loggedInAccount.displayInfo();

        System.out.print("Enter amount to deposit: ");
        double depositAmount = input.nextDouble();
        loggedInAccount.deposit(depositAmount); 

        System.out.print("Enter amount to withdraw: ");
        double withdrawAmount = input.nextDouble();
        loggedInAccount.withdraw(withdrawAmount);

        loggedInAccount.displayInfo();

        input.close();
    }
}