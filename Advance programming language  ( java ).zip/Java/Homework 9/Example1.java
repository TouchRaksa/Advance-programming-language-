class Rectangle {
    double width;
    double height;
    Rectangle (double width, double height) {
        this.width = width;
        this.height = height;
    }
    double width() {
        return width;
    }
    double height() {
        return height;
    }
    double getArea() {
        return width * height;
    }
    double getParimeter() {
        return 2 * (width + height);
    }
}
public class Example1 {
    public static void main(String[] args) {
        Rectangle obj1 = new Rectangle(4, 40);
        Rectangle obj2 = new Rectangle(3.5, 35.7);
        System.out.printf("Rectangle1 width = " + obj1.width() + "  height = " + obj1.height() + "  area = " + obj1.getArea() + "  parimeter = " + obj1.getParimeter());
        System.out.println();
        System.out.printf("Rectangle2 width = " + obj2.width() + "  height = " + obj2.height() + "  area = " + obj2.getArea() + "  parimeter = " + obj2.getParimeter());
    }
}