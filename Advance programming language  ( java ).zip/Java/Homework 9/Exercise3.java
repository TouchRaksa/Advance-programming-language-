import java.util.Scannrer;
import java.util.HashMap;
class Subject {
    void studend1 () {
        HashMap <String, Integer> score = new HashMap<>();
        score.put("Math", 90);
        score.put("English", 85);

        int value = score.get("Math");
        int value1 = score.get("English");

        System.out.println(value);
        System.out.println(value1);
    }
    void studend2 () {
        HashMap <String, Integer> score = new HashMap<>();
        score.put("Math", 60);
        score.put("English", 60);
    }
}
class Name {

}
public class Exercise3 {
    public static void main(String[] args) {
        Subject obd = new Subject();
        System.out.println(obd.studend1());
    }
}
