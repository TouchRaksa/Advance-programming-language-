import java.util.Scanner;

class Calculator {
    double num1;
    double num2;
    char sign;

    Calculator(double num1, char sign, double num2) {
        this.num1 = num1;
        this.sign = sign;
        this.num2 = num2;
    }
    double add() {
        return num1 + num2;
    }

    double subtract() {
        return num1 - num2;
    }

    double multiply() {
        return num1 * num2;
    }

    double divide() {
        return num2 != 0 ? num1 / num2 : Double.NaN;
    }

    double power() {
        return Math.pow(num1, num2);
    }

    double modulo() {
        return num1 % num2;
    }
    void calculate() {
        double result;
        switch (sign) {
            case '+':
                result = add();
                break;
            case '-':
                result = subtract();
                break;
            case '*':
                result = multiply();
                break;
            case '/':
                if (num2 == 0) {
                    System.out.println("Cannot divide by zero.");
                }
                result = divide();
                break;
            case '^':
                result = power();
                break;
            case '%':
                result = modulo();
                break;
            default:
                System.out.println("Invalid operator. Use +, -, *, /, ^, or %.");
                return;
        }

        // Display output
        System.out.printf("%.2f %c %.2f = %.2f", num1, sign, num2, result);
    }
}

public class Exercise2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter expression: ");
        String line = input.nextLine();
        input.close();

        // Split input by space
        String[] parts = line.trim().split(" ");

        double num1 = Double.parseDouble(parts[0]);
        char sign = parts[1].charAt(0);
        double num2 = Double.parseDouble(parts[2]);
        Calculator calculator = new Calculator(num1, sign, num2);
        calculator.calculate();
    }
}