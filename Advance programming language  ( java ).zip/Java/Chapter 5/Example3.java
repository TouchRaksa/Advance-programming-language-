import java.util.Arrays;

public class Example3 {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5};
        int random_index, temp;
        for (int i = 0; i < array.length; i ++) {
            random_index = (int)(Math.random() * 5);

            if (i == random_index) {
                continue;
            }
            temp = array[i];  
            array[i] = array[random_index];
            array[random_index] = temp;
        }
        System.out.print(Arrays.toString(array)); 
    }
}
