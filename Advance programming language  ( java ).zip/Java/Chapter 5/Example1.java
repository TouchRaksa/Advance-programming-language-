
public class Example1 {
    public static void main(String[] args) {
        // Random from 0 to 10
        int rand = (int)(Math.random() * 10);

        // Random from 50 to 100
        int rand1 = 50 + (int)(Math.random() * 51);
        
        // Random from a to a+b
        int a = 0, b = 11;
        int rand2 = (int)(a + Math.random() * b);

        System.out.println(rand + "\t" + rand1 + "\t" + rand2 + "\t");
    }
}   