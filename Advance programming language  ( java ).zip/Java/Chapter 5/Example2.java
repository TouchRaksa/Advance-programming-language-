public class Example2 {
    public static void main(String[] args) {
        int[][] matrix = new int[4][3];
        // Create loop for random to find number row and column
        for (int row = 0; row < matrix.length ; row++) {
            for (int col = 0; col < matrix[row].length; col++) {
                matrix[row][col] = (int)(Math.random() * 100);
            }
        }

        // Use loop for print matrix
        for (int row = 0; row < matrix.length; row++) {
            for (int col = 0; col < matrix[row].length; col++) {
                System.out.printf ("%-3d " , matrix[row][col]);
            }
            System.out.println();
        }
    }
}
