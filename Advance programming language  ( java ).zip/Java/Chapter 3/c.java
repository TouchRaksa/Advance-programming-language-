
public class c {
    public static void main(String[] args) {
        for (String i : new String[] {"ab", "cd", "ef"}){
            System.out.println(i + "\t");
        }
    }
}