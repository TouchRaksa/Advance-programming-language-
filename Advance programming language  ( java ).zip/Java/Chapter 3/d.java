
public class d {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4};
        int[] arraycopy = new int[array.length];
        for (int i = 0; i < array.length; i++){
            arraycopy[i] = array[i];
        }
        for (int j : arraycopy) {
            System.out.print(j + " ");
        }
    }
}