
public class a {
    public static void main(String[] args) {
        double[] array = new double[10];
        System.out.println(array.length);
    }
}