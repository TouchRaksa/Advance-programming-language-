import java.util.Arrays;

public class e {
    public static void main(String[] args) {
        int[] num = {1, 3, 5, 6, 7};
        System.out.println(Arrays.toString(num));
    }
}
