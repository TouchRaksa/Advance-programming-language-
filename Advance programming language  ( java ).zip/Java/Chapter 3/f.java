import java.util.Arrays;

public class f {
    public static void main(String[] args) {
        int[] arr = {10, 20, 30, 40, 50, 60, 70, 80, 90};
        System.out.println("10 is index: " + Arrays.binarySearch(arr, 10));
    }
}