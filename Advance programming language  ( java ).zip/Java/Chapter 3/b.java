
public class b {
    public static void main(String[] args) {
        double[] array = {3.3, 4.5, 7.2};
        for (double i : array) {
            System.out.println(i + "\t");
        }
    }
}
