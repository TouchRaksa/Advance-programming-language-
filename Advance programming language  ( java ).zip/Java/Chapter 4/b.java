
public class b {
    public static void main(String[] args) {
        int[][] number = {{2, 1, 3}, {4, 5, 6, 7, 8}, {10, 20}};
        System.out.print(number[1][2]);
    }
}
