import java.util.Scanner;
public class c {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[][] matrix = new int[3][4];
        System.out.print("Enter " + matrix.length + " rows and " + matrix[0].length + " columns");

        for (int rows = 0; rows < matrix.length; rows++){
            for (int cols = 0; cols < matrix[rows].length; cols++) {
                matrix[rows][cols] = input.nextInt();
            }
        }
        input.close();

        System.out.println();
        for (int rows = 0; rows < matrix.length; rows++) {
            for (int columns = 0; columns < matrix[rows].length; columns++) {
                System.out.printf("%-3d" , matrix[rows][columns]);
            }
            System.out.println();
        }
    }
}
