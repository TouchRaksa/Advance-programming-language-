import java.util.Arrays;

public class D {
    public static void main(String[] args) {
        double[][][] number = {
            {{17.5, 28.5}, {4.0, 12.5}, {15, 43.5}, {53, 21.5}, {15, 2.5}},
            {{4.5, 21.5}, {9.0, 52.5}, {35, 34.5}, {12, 20.5}, {14, 9.5}},
            {{3.5, 30.5}, {8.4, 10.5}, {11, 33.5}, {21, 23.5}, {10, 2.5}},
            {{6.5, 23.5}, {9.4, 32.5}, {13, 34.5}, {55, 20.5}, {40, 7.5}},
            {{8.5, 26.5}, {5.4, 52.5}, {15, 36.5}, {63, 24.5}, {18, 2.5}},
            {{9.5, 20.5}, {9.4, 42.5}, {23, 31.5}, {42, 20.5}, {16, 6.5}}
        };
        System.out.println(Arrays.deepToString(number[0])); // Prime index
        System.out.println(Arrays.toString(number[0][1])); // Prime index and row
        System.out.println(number[5][2][1]); // Prime index row and cols
        System.out.println(number[1][3][1]);
        System.out.println(number.length); // Prime number of index
        System.out.println(number[0].length); // Prime number in index
        System.out.println(number[2][2].length); // Prime number in index and in row
    }
}
