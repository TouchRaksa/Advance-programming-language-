import java.util.HashMap;
public class Access_Element {
    public static void main(String[] args) {
        HashMap<Integer, String> length = new HashMap<>();
        length.put(1, "Java");
        length.put(2, "C++");
        length.put(3, "Phyton");
        // Use get()
        String value = length.get(2);
        // Use getOrDefault
        String values = length.getOrDefault(4, "Value is not found");

        System.out.println(value);
        System.out.println(values); 
        System.out.println("key: " + length.keySet()); // Use keySet() for return value of key
        System.out.println("value: " + length.values()); // Use values for return value of values()
    }
}