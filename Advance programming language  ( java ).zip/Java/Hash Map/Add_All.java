import java.util.HashMap;

public class Add_All {
    public static void main(String[] args) {
        HashMap<String, Integer> HashMap1 = new HashMap<>();
        HashMap1.put("java", 1);
        HashMap1.put("c++", 2);

        HashMap<String, Integer> HashMap2 = new HashMap<>();
        HashMap2.put("HTML", 3);
        HashMap2.put("CSS", 4);

        // Add all element from hash map 2 to hash mmap 1
        HashMap1.putAll(HashMap2);

        System.out.print(HashMap1);
    }
}
