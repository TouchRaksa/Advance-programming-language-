import java.util.HashMap;
public class Update_Element {
    public static void main(String[] args) {
        HashMap<Integer, String> language = new HashMap<>();
        language.put(1, "Phyton");
        language.put(2, "java");
        language.put(3, "C++");
        // Replace map for key 2
        String value = language.replace(2, "HTML");
        System.out.println(value);
        System.out.println(language);

        // Use repalceAll()
        HashMap<Integer, String> language1 = new HashMap<>();
        language1.put(1, "Java");
        language1.put(2, "MySQL");
        language1.put(3, "Ruby");

        language1.replaceAll((key, values) -> value.toUpperCase());
        System.out.println(language1);

        // Use Remove(key) for remove 
        HashMap<Integer, String> language2 = new HashMap<>();
        language2.put(1, "Java");
        language2.put(2, "Phyton");
        language2.put(3, "Ruby");
        String num = language2.remove(2);
        System.out.println(num);
        System.out.println(language2);
    }
}