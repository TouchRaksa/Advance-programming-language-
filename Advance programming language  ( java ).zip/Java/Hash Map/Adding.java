import java.util.HashMap;
public class Adding {
    public static void main(String[] args) {
        // Create a Hash map
        HashMap<String, Integer> score = new HashMap<>();

        // Add element to hash map
        score.put("DSA", 100);
        score.put("APL", 90);
        score.put("WEB", 80);
        System.out.println(score);
    }
}
