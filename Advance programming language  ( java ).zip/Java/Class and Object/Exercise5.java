class wall {
    double length;
    double height;
    wall() {
        length = 1;
        height = 2;
    }
    wall(double length) {
        length = 3;
        this.length = length;
    }
    wall(double length, double height) {
        this.length = length;
        this.height = height;
    }
    double CalculateArea() {
        return length * height;

    }
}
public class Exercise5 {
    public static void main(String[] args) {
        wall walls = new wall(2.2, 3.3);
        System.out.println("wall = " + walls.CalculateArea());
    }
}