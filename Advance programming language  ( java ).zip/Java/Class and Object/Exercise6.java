class wall {
    double length;
    double height;
    wall (double length, double height) {
        this.length = length;
        this.height = height;
    }
    double CalculateArea() {
        return length * height;
    }
}
public class Exercise6 {
    public static void main(String[] args) {
        System.out.println("wall = " + new wall(2.2, 3.3).CalculateArea());
    }
}
