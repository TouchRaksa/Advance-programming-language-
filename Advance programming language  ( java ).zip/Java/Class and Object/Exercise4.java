class wall {
    double length;
    double height;
    wall(double length, double height) {
        this.length = length;
        this.height = height;
    }
    double CalculateArea() {
        return length * height;
    }
}
public class Exercise4 {
    public static void main(String[] args) {
        wall walls = new wall(10.5, 5.5);
        System.out.println("wall = " + walls.CalculateArea());
    }
}
