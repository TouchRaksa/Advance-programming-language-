class wall {
    double length;
    double height;
    wall(double i, double h) {
        length = i;
        height = h;
    }
    double CalculateArea() {
        return length * height;
    }
}
public class Exercise3 {
    public static void main(String[] args) {
        wall wall1 = new wall(10.5, 8.6);
        wall wall2 = new wall(8.5, 6.3);
        System.out.println("Area of wall1 = " + wall1.CalculateArea());
        System.out.println("Area of wall2 = " + wall2.CalculateArea());
    }
}
