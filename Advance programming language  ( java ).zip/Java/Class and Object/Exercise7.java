class circle {
    double reduis;
    circle (double reduis) {
        this.reduis = reduis;
    }
    double getArea() {
        return Math.pow(reduis, 2) * 3.14;
    }
}
public class Exercise7 {
    public static void main(String[] args) {
        circle[] circlesArray = new circle[3];
        for (int i = 0; i < circlesArray.length; i++) {
            circlesArray[i] = new circle(Math.random());
        }
        for (int i = 0; i < circlesArray.length; i++) {
            double area = circlesArray[i].getArea();
            System.out.printf("Area of Circle %d: %.2f\n", i, area);
        }
    }
}
