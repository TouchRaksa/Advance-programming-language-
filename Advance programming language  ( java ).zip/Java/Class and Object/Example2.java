class  wall {
    double length;
    wall() {
        length = 5.5;
        System.out.println("Creating a wall");
        System.out.println("Length = " + length);
    }
}
public class Example2 {
    public static void main(String[] args) {
        wall wall1 = new wall();
    }
}