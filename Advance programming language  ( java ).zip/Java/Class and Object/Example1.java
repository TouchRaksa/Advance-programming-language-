// Use PascalCase for class name
class Cylinder {
    double radius;
    double height;

    double calculateArea() {
        return radius * radius * Math.PI;
    }

    double calculateVolume() {
        return radius * radius * Math.PI * height;
    }
}
public class Example1 {
    public static void main(String[] args) {
        // Create object
        Cylinder cylinder1 = new Cylinder();

        // Access fields and methods
        cylinder1.radius = 2.5;
        cylinder1.height = 3;

        double area = cylinder1.calculateArea();
        double volume = cylinder1.calculateVolume();

        // Display the result
        System.out.println("Area = " + area);
        System.out.println("Volume = " + volume);
    }
}
