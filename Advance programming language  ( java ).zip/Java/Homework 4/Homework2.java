
public class Homework2 {
    public static void main(String[] args) {
        int[][] number = {
            {1},
            {5, 2},
            {9, 6, 3},
            {13, 10, 7, 4},
            {14, 11, 8},
            {15, 12}, 
            {16}
        };
        // Loop index of array
        for (int row = 0; row < number.length; row++) {
            // Loop element of index
            for (int cols = 0; cols < number[row].length; cols ++) {
                System.out.print(number[row][cols] + " ");
            }
            System.out.println();
        }
    }
} 