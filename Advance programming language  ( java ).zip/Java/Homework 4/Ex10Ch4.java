public class Ex10Ch4 {
    public static void main(String[] args) {
        int banks = 5;
        double[] b = {25, 100.5, 0, 0, 320.5};
        double[][] borrowsers = {
            {0, 100.5, 0, 0, 320.5},
            {0, 0, 40, 85, 0},
            {125, 0, 0, 75, 0},
            {125, 0, 0, 0, 75},
            {0, 0, 0, 0, 0}
        };
        double limit = 210.5;

        // Print out unsafe banks
        System.out.print("Unsafe banks are ");
        for (int k = 0; k < banks; k++) {
            double totalLoans = 0;
            for (int l = 0; l < banks; l++) {
                totalLoans += borrowsers[k][l];
            }
            if (totalLoans + b[k] < limit) {
                System.out.print(k + " ");
                // Reset loans for this bank
                for (int m = 0; m < banks; m++) {
                    borrowsers[m][k] = 0;
                }
            }
        }
    }
}