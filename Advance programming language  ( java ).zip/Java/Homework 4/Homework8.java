import java.util.Scanner;

public class Homework8 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Please input number of students: ");
        int number = input.nextInt();

        // Create arrays to store the scores for each student
        int[] math = new int[number];
        int[] physic = new int[number];
        int[] chemistry = new int[number];
        int[] totals = new int[number];

        // Collect the data for each student
        for (int i = 0; i < number; i++) {
            System.out.println("Student " + (i + 1));
            System.out.print("Math: ");
            math[i] = input.nextInt();

            System.out.print("Physics: ");
            physic[i] = input.nextInt();

            System.out.print("Chemistry: ");
            chemistry[i] = input.nextInt();

            // total score
            totals[i] = math[i] + physic[i] + chemistry[i];
        }
        
        // Print the table header once
        System.out.println("......................................................");
        System.out.println("\nStudent        Math    Physics    Chemistry    Total");
        System.out.println("......................................................");

        // Print the results for each student
        for (int i = 0; i < number; i++) {
            System.out.printf("Student %-6d %-8d %-9d %-12d %-6d", (i + 1), math[i], physic[i], chemistry[i], totals[i]);
            System.out.println();
        }
        System.out.println("......................................................");
        input.close();
    }
}