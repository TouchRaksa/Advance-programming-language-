import java.util.Arrays;

public class Homework4 {
    public static void main(String[] args) {
        double[][][] number = {
            {{1, 3}, {13, 15, 17}}, {{1, 3}, {5, 7}, {9, 11}, {13, 15, 17}},
            {{13, 15, 17}, {1, 3}}, {{1, 3}, {5, 7}, {9, 11}, {13, 15, 17}},
            {{15, 17, 13}, {1, 3}}, {{1, 3}, {5, 7}, {9, 11}, {13, 15, 17}}
        };
        boolean bool = true;
        for (int i = 0; i < number.length - 1; i += 2) { 
            // Compare adjacent pairs (0-1, 2-3, 4-5)
            if (!Arrays.deepEquals(number[i], number[i + 1])) {
                bool = true;
                System.out.println(bool);
            }
        }
    }
}