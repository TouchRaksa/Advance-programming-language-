public class Exercise10 {
    public static void main(String[] args) {
        int amountBank = 5;
        double Limit = 201.0;
        double totalAsset = 0;
        double[][] Bank={
                { 25, 100.5, 0, 0, 320.5 },
                { 0, 125, 40, 85, 0 },
                { 125, 0, 175, 75, 0 },
                { 125, 0, 0, 75, 0 },
                { 0, 0, 125, 0, 181 },
                        
        };

        for (int i = 0; i < Bank.length; i++) {
            for (int j = 0; j < amountBank; j++) {
                totalAsset += Bank[i][j];
            }
            if (totalAsset < Limit) {
                System.out.print("Bank: " + i);
            }
            totalAsset = 0;
        }
    }
}
