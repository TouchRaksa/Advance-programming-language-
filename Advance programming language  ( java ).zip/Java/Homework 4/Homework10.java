public class Homework10 {
    public static void main(String[] args) {
        double[][] money = {
            {25, 100.5, 320.5},
            {125, 85, 40},
            {75, 125, 75}, 
            {75, 125},
            {181, 125}
        };
        // Loop index of Array
        for (int i = 0; i < money.length; i++) {
            double total = 0;
            // Loop element of index
            for (int j = 0; j < money[i].length; j++) {
                total += money[i][j]; // Sum row elements
            }
            // Check if the row is unsafe (after summing)
            if (total < 201) {
                System.out.println("Bank " + (i) + " is unsafe.");
            }
        }
    }
}