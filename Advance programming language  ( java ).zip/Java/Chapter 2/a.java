public class a {
    public static void main(String[] args){
        String str = "welcome to java";
        System.out.println("length of the str is " + str.length());
        System.out.println("Chatacter of index 5 is " + str.charAt(5));                    
        System.out.println(str.toUpperCase());
        System.out.println(str.toLowerCase());
        System.out.println("After trimed length is" + str.trim());
    }
}