import java.util.Scanner;
public class T {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Input a string: ");
        StringBuilder word = new StringBuilder(input.nextLine());
        input.close();
        System.out.println (word);
    }
}