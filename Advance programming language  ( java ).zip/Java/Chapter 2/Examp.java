public class Examp {
    public static void main(String[] args){
        String str = "Hello";
        str = str + " world";
        System.out.println(str);
    }
}