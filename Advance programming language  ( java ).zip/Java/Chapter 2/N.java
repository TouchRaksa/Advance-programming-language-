public class N {
    public static void main(String[] args) {
        StringBuilder str = new StringBuilder("this is a program");
        str.replace(0, 9, "java");
        System.out.println(str);
    }
}
