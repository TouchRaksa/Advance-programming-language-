public class b {
    public static void main(String[] ar){
        String str1 = "Hello";
        String str2 = "Hi";
        System.out.println(str1.toUpperCase());
        if (str1.equals(str2)){
            System.out.println("str1 equal str2");
        } else {
            if (str1.compareTo(str2) > 0){
                System.out.println("str1 is greater than str2");
            } else {
                System.out.println("str2 id greater than str1");
            }
        }
    }
}