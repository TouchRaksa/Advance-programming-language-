
public class D {
    public static void main(String[] arsl){
        int num1 = 10;
        String str1 = "Java is " + "awesome";
        String str2 = "num1 si " + num1;
        String str3 = "The first aphaber is " + 'a';
        String str4 = "2 * 5 is " + 2 * 5;
        System.out.println(str1);
        System.out.println(str2);
        System.out.println(str3);
        System.out.println(str4);
    }
}