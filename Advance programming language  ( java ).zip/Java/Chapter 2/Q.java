public class Q {
    public static void main(String[] args) {
        StringBuilder str = new StringBuilder("This is a program");
        str.reverse();
        System.out.println(str);
    }
}
