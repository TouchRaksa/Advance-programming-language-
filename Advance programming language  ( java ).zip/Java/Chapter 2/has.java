public class has {
    public static void main(String[] args){
        char ch1 = 'D', ch2 = 'Z', ch3 = '?';
        System.out.println(Character.isLetter(ch1));
        System.out.println(Character.isDigit(ch2));
        System.out.println(Character.isLetterOrDigit(ch3));
    }
}
