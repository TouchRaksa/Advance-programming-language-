public class O {
    public static void main(String[] args) {
        StringBuilder str = new StringBuilder("This is a program");
        str.deleteCharAt( 5);
        System.out.println(str);
    }
}
