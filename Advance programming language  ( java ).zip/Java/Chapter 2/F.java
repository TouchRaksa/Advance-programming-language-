
public class F {
    public static void main(String[] ars){
        String str = "Hello World Hello";
        str = str.replaceAll("Hello", "Hi");
        System.out.println(str);
    }
}
