public class Example 
{
    public static void main(String[] args)
    {
        char ch = 'D';
        if (ch >= 'A' && ch <= 'Z')
        {
            System.out.println(ch + " is an upercase letter");
        }
        else if (ch >= 'a' && ch <= 'z')
        {
            System.out.println(ch + " is an lowercase letter");
        }
        else if (ch >= 0 && ch <= 9)
        {
            System.out.println(ch + " is a numberic charachor");
        }
    }
}