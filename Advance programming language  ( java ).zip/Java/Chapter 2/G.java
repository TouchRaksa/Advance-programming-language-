
public class G {
    public static void main(String[] args){
        String str = "Hello ";
        StringBuilder strSB = new StringBuilder(str);
        strSB.append("Java");
        System.out.println(strSB);
    }
}
