public class M {
    public static void main(String[] args) {
        StringBuilder str = new StringBuilder("This is a program");
        str.insert(10, "java ");
        System.out.println(str);
    }
}
