
public class E {
    public static void main(String[] atgs){
        String str = "Hwllo horkd";
        str = str.replace("o", "X");
        System.out.println(str);
    }
}