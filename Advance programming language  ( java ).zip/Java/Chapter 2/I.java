
public class I {
    public static void main(String[] args){
        StringBuilder str = new StringBuilder("This is a paragraph");
        System.out.println(str.length());
    }
}
