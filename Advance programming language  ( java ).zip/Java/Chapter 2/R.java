public class R {
    public static void main(String[] args) {
        StringBuilder str = new StringBuilder("This is a program");
        System.out.println(str.length());
    }
}