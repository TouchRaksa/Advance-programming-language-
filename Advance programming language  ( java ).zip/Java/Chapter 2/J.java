
public class J {
    public static void main(String[] args){
        StringBuilder str = new StringBuilder("This is a program");
        str.setCharAt(8, 'n');
        System.out.println(str);
    }
}