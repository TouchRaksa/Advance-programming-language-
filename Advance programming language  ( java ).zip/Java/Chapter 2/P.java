public class P {
    public static void main(String[] args) {
        StringBuilder str = new StringBuilder("this is a program");
        str.delete(0, 5);
        System.out.println(str);
    }
}