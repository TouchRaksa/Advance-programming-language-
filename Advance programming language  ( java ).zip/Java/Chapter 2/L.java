public class L {
    public static void main(String[] args) {
        StringBuilder str = new StringBuilder("hello ");
        str.append("java");
        System.out.println(str);
    }
}
