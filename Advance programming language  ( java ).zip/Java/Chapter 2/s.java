public class s {
    public static void main(String[] args) {
        StringBuilder str = new StringBuilder("This is a program");
        str.setCharAt(5, 'M');
        System.out.println(str);
    }
}