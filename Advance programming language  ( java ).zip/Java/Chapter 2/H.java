
public class H {
    public static void main(String[] args){
        StringBuilder str = new StringBuilder("Hello Java");
        str.reverse();
        System.out.println(str);
    }
}