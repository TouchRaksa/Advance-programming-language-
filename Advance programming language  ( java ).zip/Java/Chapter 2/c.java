public class c {
    public static void main(String[] as){
        String str1 = "Wellcome";
        String str2 = "java";
        String str3 = str1 + " to " + str2;
        System.out.println(str3);
    }
}
